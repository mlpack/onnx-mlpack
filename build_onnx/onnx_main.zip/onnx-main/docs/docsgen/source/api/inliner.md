# onnx.inliner

## inline_local_functions

```{eval-rst}
.. autofunction:: onnx.inliner.inline_local_functions
```

## inline_selected_functions

```{eval-rst}
.. autofunction:: onnx.inliner.inline_selected_functions
```
